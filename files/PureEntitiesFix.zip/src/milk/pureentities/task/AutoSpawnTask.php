<?php

namespace milk\pureentities\task;

use pocketmine\scheduler\Task;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;
use milk\pureentities\PureEntities;

class AutoSpawnTask extends Task implements Listener {

    private $plugin;

    public function __construct(PureEntities $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun($currentTick) {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            $this->checkPlayerMovement($player);
        }
    }

    public function checkPlayerMovement(Player $player) {
        $world = $player->getLevel()->getFolderName();

        if ($world === "world" && $player->distance($player->getLevel()->getSpawnLocation()) >= 30) {
            $levelTime = $player->getLevel()->getTime();
            
            // JIKA MALAM HARI (Monster)
            if ($levelTime >= 14000 && $levelTime <= 22000) {
                $x = $player->getX() + mt_rand(-12, 12); // Diperluas ke 12 blok
                $y = $player->getY();
                $z = $player->getZ() + mt_rand(-12, 12);

                $spawnLocation = new Vector3($x, $y, $z);
                if (!$this->plugin->isTorchNearby($player->getLevel(), $x, $y, $z, 7) && $this->plugin->isSafeSpawnLocation($player->getLevel(), $spawnLocation)) {
                    $this->plugin->invocarMob($player);
                }
            } 
            // JIKA SIANG HARI (Hewan / Animal)
            else {
                // Membuat perulangan agar memunculkan 3 sampai 5 hewan sekaligus secara acak
                $jumlahHewan = mt_rand(1, 3); 
                
                for ($i = 0; $i < $jumlahHewan; $i++) {
                    $x = $player->getX() + mt_rand(-15, 15); // Jarak diperluas agar tidak menumpuk di satu titik
                    $y = $player->getY();
                    $z = $player->getZ() + mt_rand(-15, 15);

                    $spawnLocation = new Vector3($x, $y, $z);
                    if ($this->plugin->isSafeSpawnLocation($player->getLevel(), $spawnLocation)) {
                        $this->plugin->invocarAnimal($player);
                    }
                }
            }
        }
    }
}
