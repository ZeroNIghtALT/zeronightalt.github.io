<?php
namespace Sergey_Dertan\SClearLagg\Command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat as F;
use Sergey_Dertan\SClearLagg\SClearLaggMainFolder\SClearLaggMain;

/**
 * Class SClearLaggCommandExecutor
 * @package Sergey_Dertan\SClearLagg\Command
 */
class SClearLaggCommandExecutor
{
    /**
     * @param CommandSender $s
     * @param Command $cmd
     * @param array $args
     */
    function __construct(CommandSender $s, Command $cmd, array $args)
    {
        $this->executeCommand($s, $cmd, $args);
    }

    /**
     * @param CommandSender $s
     * @param Command $cmd
     * @param array $args
     * @return bool
     */
    private function executeCommand(CommandSender $s, Command $cmd, array $args)
    {
        $main = SClearLaggMain::getInstance();
        $entitiesManager = $main->getEntityManager();
        switch ($cmd->getName()) {
            case"scl":
                if (!isset($args[0])) {
                    $s->sendMessage(F::RED . "ClearLagg" . $main->getDescription()->getVersion() . "\n §b/scl clear §e- §6Menghilangkan lag\n §b/scl mobkill §e- §6Menghilangkan Mob");
                    return true;
                }
                if (!in_array(strtolower($args[0]), array("clear", "mobkill"))) {
                    $s->sendMessage(F::RED . "Command ' $args[0] ' Tidak ditemukan\n Use ' /scl 'Untuk Melihat seluruh commanf");
                    return true;
                }
                switch (array_shift($args)) {
                    case"clear":
                        $s->sendMessage(F::YELLOW . "Menarik " . $entitiesManager->removeEntities() . " item");
                        return true;
                        break;
                    case"mobkill":
                        $s->sendMessage(F::YELLOW . "Menghilangkan " . $entitiesManager->removeMobs() . " mobs");
                        return true;
                        break;
                }
                break;
        }
        return true;
    }
}